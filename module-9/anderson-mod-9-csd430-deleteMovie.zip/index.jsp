<%--
    Zachary Anderson
    CSD430
    2/18/26
    Project3 - Index / Home Page
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="beans.MoviesBean" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Movie Database</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #fff;
            color: #222;
        }
        h1 { font-size: 22px; margin-bottom: 4px; }
        p  { font-size: 14px; color: #555; }
        hr { border: none; border-top: 1px solid #ddd; margin: 20px 0; }
        nav a {
            display: block;
            padding: 10px 14px;
            margin-bottom: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #222;
            font-size: 14px;
        }
        nav a:hover { background: #f5f5f5; }
        .db-status { font-size: 13px; color: #555; margin-top: 20px; }
        .footer { font-size: 11px; color: #aaa; margin-top: 30px; }
    </style>
</head>
<body>

<h1>Movie Database</h1>
<p>CSD430 &ndash; Zachary Anderson &ndash; Project Part 3</p>
<hr>

<nav>
    <a href="addMovie.jsp">Add a New Movie</a>
    <a href="displayMovies.jsp">View All Movies</a>
    <a href="movieLookup.jsp">Movie Lookup</a>
    <a href="deleteMovie.jsp">Delete a Movie</a>
</nav>

<hr>

<h3>Update Existing Movie</h3>

<%
    MoviesBean bean = new MoviesBean();
    List<MoviesBean> movies = bean.getAllMovies();
%>

<form action="updateForm.jsp" method="post">

    Select Movie ID:

    <select name="movieId" required>
        <% for (MoviesBean m : movies) { %>
            <option value="<%= m.getMovieId() %>">
                <%= m.getMovieId() %> - <%= m.getTitle() %>
            </option>
        <% } %>
    </select>

    <br><br>

    <input type="submit" value="Edit Selected Movie">

</form>


<%
    int movieCount = 0;
    boolean dbOk = false;
    try {
        MoviesBean checkBean = new MoviesBean();
        List<MoviesBean> checkList = checkBean.getAllMovies();
        movieCount = checkList.size();
        dbOk = true;
    } catch (Exception e) {
        dbOk = false;
    }
%>

<div class="db-status">
    <% if (dbOk) { %>
        Database connected &mdash; <em>zachary_movies_data</em> contains <strong><%= movieCount %></strong> record<%= movieCount == 1 ? "" : "s" %>.
    <% } else { %>
        Database connection failed. Check MySQL and MoviesBean credentials.
    <% } %>
</div>

<p class="footer">CSD430 | Project Part 3 | Zachary Anderson | 2/18/26</p>

</body>
</html>
