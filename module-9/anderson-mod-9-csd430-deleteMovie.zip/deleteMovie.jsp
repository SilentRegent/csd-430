<%--
    Zachary Anderson
    CSD430
    2/27/26
    Project Part 4 - Delete Movie (Main Form)
--%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="beans.MoviesBean" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Movie Database</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #fff;
            color: #222;
        }
        h1 { font-size: 22px; margin-bottom: 4px; }
        p  { font-size: 14px; color: #555; }
        hr { border: none; border-top: 1px solid #ddd; margin: 20px 0; }
        nav a {
            display: block;
            padding: 10px 14px;
            margin-bottom: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #222;
            font-size: 14px;
        }
        nav a:hover { background: #f5f5f5; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            margin-bottom: 16px;
        }
        thead tr { background: #222; color: #fff; }
        th, td {
            padding: 9px 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        tbody tr:nth-child(even) { background: #f9f9f9; }
        tbody tr:hover           { background: #f0f0f0; }

        .empty-msg {
            font-style: italic;
            color: #888;
            font-size: 14px;
        }

        select {
            padding: 6px 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 8px;
        }
        input[type="submit"] {
            padding: 7px 16px;
            background: #c0392b;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
        }
        input[type="submit"]:hover { background: #a93226; }

        .db-status { font-size: 13px; color: #555; margin-top: 20px; }
        .footer { font-size: 11px; color: #aaa; margin-top: 30px; }
    </style>
</head>
<body>

<h1>Movie Database</h1>
<p>CSD430 &ndash; Zachary Anderson &ndash; Project Part 4</p>
<hr>

<nav>
    <a href="index.jsp">&larr; Back to Home</a>
</nav>

<hr>

<h3>All Movies</h3>

<%
    MoviesBean bean = new MoviesBean();
    List<MoviesBean> movies = bean.getAllMovies();

    boolean hasError = (movies.size() == 1 && movies.get(0).getMovieId() == 0
                        && movies.get(0).getTitle().startsWith("ERROR"));
    if (hasError) { movies.clear(); }
%>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Genre</th>
            <th>Year</th>
            <th>Rating</th>
        </tr>
    </thead>
    <tbody>
        <% if (movies.isEmpty()) { %>
            <tr>
                <td colspan="5" class="empty-msg">No records found &mdash; the table is empty.</td>
            </tr>
        <% } else {
               for (MoviesBean m : movies) { %>
            <tr>
                <td><%= m.getMovieId() %></td>
                <td><%= m.getTitle() %></td>
                <td><%= m.getGenre() %></td>
                <td><%= m.getReleaseYear() %></td>
                <td><%= m.getRating() %></td>
            </tr>
        <%     }
           } %>
    </tbody>
</table>

<% if (!movies.isEmpty()) { %>
<h3>Delete a Movie</h3>

<form action="deleteMovieResult.jsp" method="post">

    Select Movie ID:

    <select name="movieId" required>
        <% for (MoviesBean m : movies) { %>
            <option value="<%= m.getMovieId() %>">
                <%= m.getMovieId() %> - <%= m.getTitle() %>
            </option>
        <% } %>
    </select>

    <br><br>

    <input type="submit" value="Delete Selected Movie">

</form>
<% } %>

<%
    int movieCount = 0;
    boolean dbOk = false;
    try {
        MoviesBean checkBean = new MoviesBean();
        List<MoviesBean> checkList = checkBean.getAllMovies();
        movieCount = checkList.size();
        dbOk = true;
    } catch (Exception e) {
        dbOk = false;
    }
%>

<div class="db-status">
    <% if (dbOk) { %>
        Database connected &mdash; <em>zachary_movies_data</em> contains <strong><%= movieCount %></strong> record<%= movieCount == 1 ? "" : "s" %>.
    <% } else { %>
        Database connection failed. Check MySQL and MoviesBean credentials.
    <% } %>
</div>

<p class="footer">CSD430 | Project Part 4 | Zachary Anderson | 2/27/26</p>

</body>
</html>
