// Zachary Anderson
// CSD430
// 2/14/26
// Project Part 2

package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MoviesBean - JavaBean to access and modify movie data in the CSD430 database.
 * Supports retrieving all movies, retrieving a single movie by ID,
 * and inserting a new movie record.
 * Updated to use MySQL Connector/J 9.6.0
 */
public class MoviesBean {

    // ===== Fields =====
    private int    movieId;
    private String title;
    private String genre;
    private int    releaseYear;
    private double rating;

    // ===== Database connection constants =====
    
    private final String dbURL  = "jdbc:mysql://localhost:3306/csd430?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private final String dbUser = "student1";
    private final String dbPass = "pass";

    // ===== Getters & Setters =====
    public int    getMovieId()                    { return movieId; }
    public void   setMovieId(int movieId)         { this.movieId = movieId; }

    public String getTitle()                      { return title; }
    public void   setTitle(String title)          { this.title = title; }

    public String getGenre()                      { return genre; }
    public void   setGenre(String genre)          { this.genre = genre; }

    public int    getReleaseYear()                { return releaseYear; }
    public void   setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }

    public double getRating()                     { return rating; }
    public void   setRating(double rating)        { this.rating = rating; }

    // ===== Get all movies (used for full table display) =====
    /**
     * Queries the database and returns every row from zachary_movies_data.
     * @return List of MoviesBean objects, one per row; empty list on error.
     */
    public List<MoviesBean> getAllMovies() {
        List<MoviesBean> list = new ArrayList<>();
        try {
            // Connector/J 9.6.0 driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                 PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM zachary_movies_data ORDER BY movie_id");
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    MoviesBean m = new MoviesBean();
                    m.setMovieId(rs.getInt("movie_id"));
                    m.setTitle(rs.getString("title"));
                    m.setGenre(rs.getString("genre"));
                    m.setReleaseYear(rs.getInt("release_year"));
                    m.setRating(rs.getDouble("rating"));
                    list.add(m);
                }
            }
        } catch (Exception e) {
            // Print full error as a fake record so it shows on the JSP
            MoviesBean err = new MoviesBean();
            err.setTitle("ERROR: " + e.getMessage());
            err.setGenre(e.getClass().getName());
            err.setReleaseYear(0);
            err.setRating(0.0);
            list.add(err);
            e.printStackTrace();
        }
        return list;
    }

    // ===== Get a single movie by ID =====
    /**
     * Retrieves one movie record matching the given primary key.
     * @param id  The movie_id to look up.
     * @return    A populated MoviesBean, or null if not found.
     */
    public MoviesBean getMovieById(int id) {
        MoviesBean movie = null;
        try {
            // Connector/J 9.6.0 driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                 PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM zachary_movies_data WHERE movie_id = ?")) {

                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        movie = new MoviesBean();
                        movie.setMovieId(rs.getInt("movie_id"));
                        movie.setTitle(rs.getString("title"));
                        movie.setGenre(rs.getString("genre"));
                        movie.setReleaseYear(rs.getInt("release_year"));
                        movie.setRating(rs.getDouble("rating"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return movie;
    }

    // ===== Add a new movie record =====
    /**
     * Inserts a new row into zachary_movies_data.
     * The movie_id (primary key) is assigned automatically by AUTO_INCREMENT.
     *
     * @param title        Movie title (required, max 255 chars).
     * @param genre        Genre string, e.g. "Action", "Drama".
     * @param releaseYear  Four-digit release year.
     * @param rating       IMDb-style rating between 0.0 and 10.0.
     * @return             true if the INSERT succeeded; false on error.
     */
    public boolean addMovie(String title, String genre, int releaseYear, double rating) {
        boolean success = false;
        try {
            // Connector/J 9.6.0 driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                 PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO zachary_movies_data (title, genre, release_year, rating) " +
                     "VALUES (?, ?, ?, ?)")) {

                // Bind parameters - never concatenate user input into SQL
                ps.setString(1, title);
                ps.setString(2, genre);
                ps.setInt(3, releaseYear);
                ps.setDouble(4, rating);

                int rows = ps.executeUpdate();
                success = (rows > 0); // true when at least one row was inserted
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }   
            // ===== Update an existing movie =====
    /**
     * Updates a movie record in zachary_movies_data.
    *
    * @param id           Movie ID (primary key)
    * @param title        Updated title
    * @param genre        Updated genre
    * @param releaseYear  Updated year
    * @param rating       Updated rating
    * @return             true if update succeeded
    */
    public boolean updateMovie(int id, String title, String genre,
                           int releaseYear, double rating) {

        boolean success = false;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                PreparedStatement ps = conn.prepareStatement(
                    "UPDATE zachary_movies_data " +
                    "SET title=?, genre=?, release_year=?, rating=? " +
                    "WHERE movie_id=?")) {

                ps.setString(1, title);
                ps.setString(2, genre);
                ps.setInt(3, releaseYear);
                ps.setDouble(4, rating);
                ps.setInt(5, id);

                int rows = ps.executeUpdate();
                success = (rows > 0);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return success;
    }
    

} // end MoviesBean
